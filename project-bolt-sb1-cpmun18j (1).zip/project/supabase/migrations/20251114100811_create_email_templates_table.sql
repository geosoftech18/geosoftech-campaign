/*
  # Email Templates Storage Schema

  1. New Tables
    - `email_templates`
      - `id` (uuid, primary key) - Unique identifier for each template
      - `name` (text) - Template name for easy identification
      - `recipient_first_name` (text) - Default recipient first name
      - `recipient_company_name` (text) - Default recipient company name
      - `sender_name` (text) - Sender's name
      - `sender_company` (text) - Sender's company name
      - `sender_phone` (text) - Sender's phone number
      - `sender_website` (text) - Sender's website
      - `theme` (text) - Color theme (blue, green, purple, orange)
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on `email_templates` table
    - Add policies for public access (since no auth is implemented)
*/

CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Untitled Template',
  recipient_first_name text NOT NULL DEFAULT '',
  recipient_company_name text NOT NULL DEFAULT '',
  sender_name text NOT NULL DEFAULT '',
  sender_company text NOT NULL DEFAULT '',
  sender_phone text NOT NULL DEFAULT '',
  sender_website text NOT NULL DEFAULT '',
  theme text NOT NULL DEFAULT 'blue',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access"
  ON email_templates
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public insert access"
  ON email_templates
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public update access"
  ON email_templates
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete access"
  ON email_templates
  FOR DELETE
  TO public
  USING (true);