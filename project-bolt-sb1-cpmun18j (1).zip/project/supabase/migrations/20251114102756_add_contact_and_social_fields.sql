/*
  # Add Contact and Social Media Fields

  1. Changes
    - Add `sender_email` (text) - Sender's email address
    - Add `sender_address` (text) - Sender's business address
    - Add `sender_instagram` (text) - Instagram handle
    - Add `sender_facebook` (text) - Facebook username/page
  
  2. Notes
    - All fields are nullable with empty string defaults for backwards compatibility
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_templates' AND column_name = 'sender_email'
  ) THEN
    ALTER TABLE email_templates ADD COLUMN sender_email text NOT NULL DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_templates' AND column_name = 'sender_address'
  ) THEN
    ALTER TABLE email_templates ADD COLUMN sender_address text NOT NULL DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_templates' AND column_name = 'sender_instagram'
  ) THEN
    ALTER TABLE email_templates ADD COLUMN sender_instagram text NOT NULL DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_templates' AND column_name = 'sender_facebook'
  ) THEN
    ALTER TABLE email_templates ADD COLUMN sender_facebook text NOT NULL DEFAULT '';
  END IF;
END $$;