import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface EmailTemplate {
  id?: string;
  name: string;
  recipient_first_name: string;
  recipient_company_name: string;
  sender_name: string;
  sender_company: string;
  sender_phone: string;
  sender_website: string;
  sender_email: string;
  sender_address: string;
  sender_instagram: string;
  sender_facebook: string;
  theme: 'blue' | 'green' | 'purple' | 'orange' | 'slate' | 'red';
  created_at?: string;
  updated_at?: string;
}
