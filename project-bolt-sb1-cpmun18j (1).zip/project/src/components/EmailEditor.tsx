import { Settings, User, Building2, Phone, Globe, Palette, FolderOpen, Mail as MailIcon, MapPin, Instagram, Facebook } from 'lucide-react';
import { FormData } from '../App';

interface EmailEditorProps {
  formData: FormData;
  setFormData: (data: FormData) => void;
  onOpenTemplates: () => void;
}

const themes = [
  { value: 'blue' as const, name: 'Ocean Blue', colors: 'from-blue-600 to-blue-700', bg: 'bg-blue-600' },
  { value: 'green' as const, name: 'Forest Green', colors: 'from-green-600 to-green-700', bg: 'bg-green-600' },
  { value: 'purple' as const, name: 'Royal Purple', colors: 'from-purple-600 to-purple-700', bg: 'bg-purple-600' },
  { value: 'orange' as const, name: 'Sunset Orange', colors: 'from-orange-600 to-orange-700', bg: 'bg-orange-600' },
  { value: 'slate' as const, name: 'Professional Slate', colors: 'from-slate-600 to-slate-700', bg: 'bg-slate-600' },
  { value: 'red' as const, name: 'Bold Red', colors: 'from-red-600 to-red-700', bg: 'bg-red-600' }
];

export default function EmailEditor({ formData, setFormData, onOpenTemplates }: EmailEditorProps) {
  const handleChange = (field: keyof FormData, value: string) => {
    setFormData({ ...formData, [field]: value });
  };

  return (
    <div className="space-y-6">
      {/* Action Buttons */}
      <div className="flex gap-3">
        <button
          onClick={onOpenTemplates}
          className="flex-1 flex items-center justify-center space-x-2 bg-white hover:bg-slate-50 text-slate-700 px-4 py-3 rounded-xl border-2 border-slate-200 transition-all shadow-sm hover:shadow-md"
        >
          <FolderOpen className="w-5 h-5" />
          <span className="font-semibold">My Templates</span>
        </button>
      </div>

      {/* Main Editor Card */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-white" />
            <h2 className="text-lg font-semibold text-white">Customize Email</h2>
          </div>
          <p className="text-blue-100 text-sm mt-1">Personalize your outreach message</p>
        </div>

        <div className="p-6 space-y-6">
          {/* Theme Selector */}
          <div className="space-y-4 pb-6 border-b border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wide flex items-center space-x-2">
              <Palette className="w-4 h-4 text-blue-600" />
              <span>Color Theme</span>
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {themes.map((theme) => (
                <button
                  key={theme.value}
                  onClick={() => handleChange('theme', theme.value)}
                  className={`relative p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                    formData.theme === theme.value
                      ? 'border-blue-600 bg-blue-50 shadow-md'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className={`h-8 rounded-md bg-gradient-to-r ${theme.colors} mb-2 shadow-sm`}></div>
                  <div className="text-sm font-medium text-slate-700">{theme.name}</div>
                  {formData.theme === theme.value && (
                    <div className="absolute top-2 right-2 w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Recipient Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wide flex items-center space-x-2">
              <User className="w-4 h-4 text-blue-600" />
              <span>Recipient Details</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  First Name
                </label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => handleChange('firstName', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., John"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <span>Company Name</span>
                </label>
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => handleChange('companyName', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., TechCorp"
                />
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-slate-200"></div>

          {/* Sender Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wide flex items-center space-x-2">
              <User className="w-4 h-4 text-blue-600" />
              <span>Your Details</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  value={formData.founderName}
                  onChange={(e) => handleChange('founderName', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., Amar Korde"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <span>Your Company</span>
                </label>
                <input
                  type="text"
                  value={formData.companyBrand}
                  onChange={(e) => handleChange('companyBrand', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., GEO Softech"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-slate-500" />
                  <span>Phone Number</span>
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., +1 (555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                  <Globe className="w-4 h-4 text-slate-500" />
                  <span>Website</span>
                </label>
                <input
                  type="text"
                  value={formData.website}
                  onChange={(e) => handleChange('website', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., www.yoursite.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                  <MailIcon className="w-4 h-4 text-slate-500" />
                  <span>Email Address</span>
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., hello@yourcompany.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-slate-500" />
                  <span>Business Address</span>
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                  placeholder="e.g., 123 Business Ave, Suite 100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                    <Instagram className="w-4 h-4 text-slate-500" />
                    <span>Instagram</span>
                  </label>
                  <input
                    type="text"
                    value={formData.instagram}
                    onChange={(e) => handleChange('instagram', e.target.value)}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                    placeholder="@username"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center space-x-2">
                    <Facebook className="w-4 h-4 text-slate-500" />
                    <span>Facebook</span>
                  </label>
                  <input
                    type="text"
                    value={formData.facebook}
                    onChange={(e) => handleChange('facebook', e.target.value)}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white"
                    placeholder="username"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Pro Tip Box */}
          <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-xl p-4">
            <div className="flex items-start space-x-3">
              <div className="bg-blue-600 rounded-full p-1 mt-0.5">
                <span className="text-white text-xs">💡</span>
              </div>
              <div>
                <p className="text-sm font-semibold text-blue-900 mb-1">Pro Tips</p>
                <p className="text-sm text-blue-800 leading-relaxed">
                  Personalized emails have 26% higher open rates. Choose a theme that matches your brand identity and always customize recipient details for each prospect.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
