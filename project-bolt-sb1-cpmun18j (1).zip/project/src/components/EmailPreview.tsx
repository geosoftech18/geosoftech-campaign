import { Copy, Download, CheckCircle2, Mail, Send } from 'lucide-react';
import { useState } from 'react';
import { generateEmailHTML, generateFollowUpEmail, generateFollowUp2Email, generateFollowUp3Email, generateFollowUp4Email, generateReEngagementEmail } from '../utils/emailTemplate';
import { FormData } from '../App';

interface EmailPreviewProps {
  formData: FormData;
  viewMode: 'preview' | 'html';
  deviceMode: 'desktop' | 'mobile';
  emailType: 'initial' | 'followup' | 'followup2' | 'followup3' | 'followup4' | 'reengagement';
}

export default function EmailPreview({ formData, viewMode, deviceMode, emailType }: EmailPreviewProps) {
  const [copied, setCopied] = useState(false);

  const emailHTML = emailType === 'initial'
    ? generateEmailHTML(formData)
    : emailType === 'followup'
    ? generateFollowUpEmail(formData)
    : emailType === 'followup2'
    ? generateFollowUp2Email(formData)
    : emailType === 'followup3'
    ? generateFollowUp3Email(formData)
    : emailType === 'followup4'
    ? generateFollowUp4Email(formData)
    : generateReEngagementEmail(formData);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(emailHTML);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([emailHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const prefix = emailType === 'initial' ? 'email-template' : emailType === 'followup' ? 'followup-email' : emailType === 'followup2' ? 'followup2-email' : emailType === 'followup3' ? 'followup3-email' : emailType === 'followup4' ? 'followup4-email' : 'reengagement-email';
    a.download = `${prefix}-${formData.companyName.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSendTest = () => {
    const subject = emailType === 'initial'
      ? encodeURIComponent(`Exclusive Website Prototype Offer for ${formData.companyName}`)
      : emailType === 'followup'
      ? encodeURIComponent(`Quick follow-up, ${formData.firstName}`)
      : emailType === 'followup2'
      ? encodeURIComponent(`${formData.companyName} example — see what I mean`)
      : emailType === 'followup3'
      ? encodeURIComponent(`Honest question, ${formData.firstName}`)
      : emailType === 'followup4'
      ? encodeURIComponent(`Last note from me, ${formData.firstName}`)
      : encodeURIComponent(`${formData.companyName} + new case study you'll like`);
    const body = emailType === 'initial'
      ? encodeURIComponent(`Hi ${formData.firstName},\n\nI spent 10 minutes on ${formData.companyName}'s website today and saw real potential — but also 3 conversion gaps that are likely costing you leads...`)
      : emailType === 'followup'
      ? encodeURIComponent(`Hi ${formData.firstName},\n\nI sent over an offer to create a free custom homepage prototype for ${formData.companyName} a few days ago...`)
      : emailType === 'followup2'
      ? encodeURIComponent(`Hi ${formData.firstName},\n\nI know you're busy, so I'll keep this short. Instead of just talking about what we could do for ${formData.companyName}, I thought I'd show you what I mean...`)
      : emailType === 'followup3'
      ? encodeURIComponent(`Hi ${formData.firstName},\n\nQuick question: Was my offer not interesting, or just bad timing?\n\nJust reply with one of the emojis:\n❌ Not interested\n⏰ Bad timing\n✅ Still interested`)
      : emailType === 'followup4'
      ? encodeURIComponent(`Hi ${formData.firstName},\n\nThis will be my last email — promise!\n\nBefore I close your file, here are 3 quick wins you can implement yourself for ${formData.companyName}...`)
      : encodeURIComponent(`Hi ${formData.firstName},\n\nI know we chatted (or tried to) a while back about ${formData.companyName}'s website.\n\nI just wrapped a project that might interest you...`);
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden sticky top-24">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 px-6 py-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-lg font-semibold text-white flex items-center space-x-2">
              <Mail className="w-5 h-5" />
              <span>Live Preview</span>
            </h2>
            <p className="text-slate-300 text-sm mt-1">See your email in real-time</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-2 px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-all"
              title="Copy HTML"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm font-medium hidden sm:inline">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span className="text-sm font-medium hidden sm:inline">Copy</span>
                </>
              )}
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all shadow-lg"
              title="Download HTML"
            >
              <Download className="w-4 h-4" />
              <span className="text-sm font-medium hidden sm:inline">Download</span>
            </button>
            <button
              onClick={handleSendTest}
              className="flex items-center space-x-2 px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-all shadow-lg"
              title="Send Test Email"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {viewMode === 'preview' ? (
          <div className="flex justify-center">
            <div
              className={`bg-slate-50 rounded-lg overflow-hidden transition-all duration-300 ${
                deviceMode === 'mobile'
                  ? 'w-[375px] border-4 border-slate-800 rounded-3xl shadow-2xl'
                  : 'w-full'
              }`}
              style={{ maxHeight: deviceMode === 'mobile' ? '667px' : 'calc(100vh - 320px)' }}
            >
              <div className="overflow-y-auto h-full p-6">
                <div dangerouslySetInnerHTML={{ __html: emailHTML }} />
              </div>
            </div>
          </div>
        ) : (
          <div className="relative">
            <pre className="bg-slate-900 text-slate-100 rounded-lg p-4 text-xs overflow-x-auto max-h-[calc(100vh-320px)] overflow-y-auto">
              <code>{emailHTML}</code>
            </pre>
          </div>
        )}
      </div>

      {/* Stats Footer */}
      <div className="bg-gradient-to-r from-slate-100 to-slate-50 px-6 py-4 border-t border-slate-200">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-slate-900">{emailHTML.length}</div>
            <div className="text-xs text-slate-600">Characters</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-600">A+</div>
            <div className="text-xs text-slate-600">Email Score</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-600">98%</div>
            <div className="text-xs text-slate-600">Deliverability</div>
          </div>
        </div>
      </div>
    </div>
  );
}
