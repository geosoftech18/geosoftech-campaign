import { useState, useEffect } from 'react';
import { X, Save, Trash2, Clock, Loader } from 'lucide-react';
import { supabase, EmailTemplate } from '../lib/supabase';
import { FormData } from '../App';

interface TemplateManagerProps {
  onClose: () => void;
  onLoadTemplate: (template: EmailTemplate) => void;
  currentFormData: FormData;
}

export default function TemplateManager({ onClose, onLoadTemplate, currentFormData }: TemplateManagerProps) {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [showSaveForm, setShowSaveForm] = useState(false);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error loading templates:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveTemplate = async () => {
    if (!templateName.trim()) {
      alert('Please enter a template name');
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase.from('email_templates').insert({
        name: templateName,
        recipient_first_name: currentFormData.firstName,
        recipient_company_name: currentFormData.companyName,
        sender_name: currentFormData.founderName,
        sender_company: currentFormData.companyBrand,
        sender_phone: currentFormData.phone,
        sender_website: currentFormData.website,
        sender_email: currentFormData.email,
        sender_address: currentFormData.address,
        sender_instagram: currentFormData.instagram,
        sender_facebook: currentFormData.facebook,
        theme: currentFormData.theme,
      });

      if (error) throw error;

      setTemplateName('');
      setShowSaveForm(false);
      await loadTemplates();
    } catch (error) {
      console.error('Error saving template:', error);
      alert('Failed to save template');
    } finally {
      setSaving(false);
    }
  };

  const deleteTemplate = async (id: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;

    try {
      const { error } = await supabase.from('email_templates').delete().eq('id', id);
      if (error) throw error;
      await loadTemplates();
    } catch (error) {
      console.error('Error deleting template:', error);
      alert('Failed to delete template');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-5 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white">Template Manager</h2>
            <p className="text-blue-100 text-sm mt-1">Save and load your email templates</p>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 p-2 rounded-lg transition-all"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Save Current Template */}
          <div className="mb-6">
            {!showSaveForm ? (
              <button
                onClick={() => setShowSaveForm(true)}
                className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-6 py-4 rounded-xl transition-all shadow-lg hover:shadow-xl"
              >
                <Save className="w-5 h-5" />
                <span className="font-semibold">Save Current Template</span>
              </button>
            ) : (
              <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 space-y-3">
                <input
                  type="text"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder="Enter template name..."
                  className="w-full px-4 py-3 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  autoFocus
                />
                <div className="flex gap-3">
                  <button
                    onClick={saveTemplate}
                    disabled={saving}
                    className="flex-1 flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all disabled:opacity-50"
                  >
                    {saving ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        <span>Save</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      setShowSaveForm(false);
                      setTemplateName('');
                    }}
                    className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Templates List */}
          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Saved Templates</h3>
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader className="w-8 h-8 animate-spin text-blue-600" />
                </div>
              ) : templates.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <p className="text-lg font-medium">No templates saved yet</p>
                  <p className="text-sm mt-1">Save your first template to get started</p>
                </div>
              ) : (
                templates.map((template) => (
                  <div
                    key={template.id}
                    className="bg-gradient-to-r from-slate-50 to-slate-100 border border-slate-200 rounded-xl p-4 hover:shadow-md transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-900 text-lg mb-1">
                          {template.name}
                        </h4>
                        <div className="flex items-center space-x-4 text-sm text-slate-600 mb-2">
                          <span className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>{formatDate(template.created_at!)}</span>
                          </span>
                          <span className="bg-slate-200 px-2 py-1 rounded-md text-xs font-medium capitalize">
                            {template.theme}
                          </span>
                        </div>
                        <div className="text-sm text-slate-600 space-y-1">
                          <p>
                            <span className="font-medium">To:</span> {template.recipient_first_name} at{' '}
                            {template.recipient_company_name}
                          </p>
                          <p>
                            <span className="font-medium">From:</span> {template.sender_name} ({template.sender_company})
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 ml-4">
                        <button
                          onClick={() => onLoadTemplate(template)}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all text-sm font-medium"
                        >
                          Load
                        </button>
                        <button
                          onClick={() => deleteTemplate(template.id!)}
                          className="bg-red-100 hover:bg-red-200 text-red-700 p-2 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
