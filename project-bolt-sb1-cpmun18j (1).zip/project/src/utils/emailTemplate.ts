interface EmailData {
  firstName: string;
  companyName: string;
  phone: string;
  website: string;
  email: string;
  address: string;
  founderName: string;
  companyBrand: string;
  instagram: string;
  facebook: string;
  theme: 'blue' | 'green' | 'purple' | 'orange' | 'slate' | 'red';
}

const themeColors = {
  blue: {
    primary: '#2563eb',
    primaryDark: '#1e40af',
    light: '#eff6ff',
    lighter: '#dbeafe',
    accent: '#60a5fa',
    text: '#1e40af',
  },
  green: {
    primary: '#16a34a',
    primaryDark: '#15803d',
    light: '#f0fdf4',
    lighter: '#dcfce7',
    accent: '#4ade80',
    text: '#166534',
  },
  purple: {
    primary: '#9333ea',
    primaryDark: '#7e22ce',
    light: '#faf5ff',
    lighter: '#f3e8ff',
    accent: '#c084fc',
    text: '#6b21a8',
  },
  orange: {
    primary: '#ea580c',
    primaryDark: '#c2410c',
    light: '#fff7ed',
    lighter: '#ffedd5',
    accent: '#fb923c',
    text: '#9a3412',
  },
  slate: {
    primary: '#475569',
    primaryDark: '#334155',
    light: '#f8fafc',
    lighter: '#f1f5f9',
    accent: '#64748b',
    text: '#1e293b',
  },
  red: {
    primary: '#dc2626',
    primaryDark: '#b91c1c',
    light: '#fef2f2',
    lighter: '#fee2e2',
    accent: '#f87171',
    text: '#991b1b',
  },
};

export function generateEmailHTML(data: EmailData): string {
  const colors = themeColors[data.theme];

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exclusive Website Prototype Offer for ${data.companyName}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #1e293b;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            padding: 20px;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .header {
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            padding: 40px 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 3s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 0.3; }
        }
        .header-content {
            position: relative;
            z-index: 1;
        }
        .company-name {
            font-size: 28px;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header-subtitle {
            font-size: 16px;
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .content {
            padding: 40px 30px;
        }
        .greeting {
            font-size: 20px;
            font-weight: 600;
            color: #0f172a;
            margin-bottom: 24px;
        }
        .intro-text {
            font-size: 16px;
            color: #475569;
            margin-bottom: 24px;
            line-height: 1.7;
        }
        .highlight-box {
            background: linear-gradient(135deg, ${colors.light} 0%, ${colors.lighter} 100%);
            border-left: 4px solid ${colors.primary};
            padding: 24px;
            margin: 28px 0;
            border-radius: 8px;
        }
        .highlight-box h2 {
            font-size: 18px;
            color: ${colors.text};
            margin-bottom: 16px;
            font-weight: 700;
        }
        .highlight-text {
            color: ${colors.text};
            font-size: 15px;
            line-height: 1.7;
        }
        .deliverables {
            background: #ffffff;
            border-radius: 8px;
            padding: 20px;
            margin-top: 16px;
        }
        .deliverable-item {
            display: flex;
            align-items: start;
            margin-bottom: 16px;
            padding-bottom: 16px;
            border-bottom: 1px solid #e2e8f0;
        }
        .deliverable-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        .checkmark {
            width: 24px;
            height: 24px;
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            flex-shrink: 0;
            box-shadow: 0 2px 4px rgba(34, 197, 94, 0.3);
            animation: popIn 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards;
            transform: scale(0);
        }
        @keyframes popIn {
            0% {
                transform: scale(0) rotate(0deg);
            }
            50% {
                transform: scale(1.2) rotate(180deg);
            }
            100% {
                transform: scale(1) rotate(360deg);
            }
        }
        .deliverable-item:nth-child(1) .checkmark {
            animation-delay: 0.1s;
        }
        .deliverable-item:nth-child(2) .checkmark {
            animation-delay: 0.2s;
        }
        .deliverable-item:nth-child(3) .checkmark {
            animation-delay: 0.3s;
        }
        .deliverable-item:nth-child(4) .checkmark {
            animation-delay: 0.4s;
        }
        .checkmark::after {
            content: '✓';
            color: #ffffff;
            font-weight: bold;
            font-size: 14px;
        }
        .deliverable-text {
            font-size: 15px;
            color: #334155;
            font-weight: 500;
            line-height: 1.5;
        }
        .features-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin: 24px 0;
        }
        .feature-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
            animation: slideInUp 0.6s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
        }
        @keyframes slideInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .feature-card:nth-child(1) {
            animation-delay: 0.1s;
        }
        .feature-card:nth-child(2) {
            animation-delay: 0.2s;
        }
        .feature-card:nth-child(3) {
            animation-delay: 0.3s;
        }
        .feature-card:nth-child(4) {
            animation-delay: 0.4s;
        }
        .feature-card:hover {
            border-color: ${colors.primary};
            box-shadow: 0 4px 12px ${colors.primary}1A;
            transform: translateY(-5px);
        }
        .feature-icon {
            font-size: 24px;
            margin-bottom: 8px;
        }
        .feature-title {
            font-size: 14px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 4px;
        }
        .feature-desc {
            font-size: 13px;
            color: #64748b;
            line-height: 1.4;
        }
        .stats-banner {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            padding: 24px;
            border-radius: 8px;
            margin: 28px 0;
            text-align: center;
            color: #ffffff;
            position: relative;
            overflow: hidden;
        }
        .stats-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
            animation: statsGlow 4s ease-in-out infinite;
        }
        @keyframes statsGlow {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(10px, 10px) scale(1.1); }
        }
        .stat {
            display: inline-block;
            margin: 0 20px;
            position: relative;
            z-index: 1;
        }
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: ${colors.accent};
            display: block;
            animation: countUp 2s ease-out forwards, pulse 2s ease-in-out infinite;
            transform-origin: center;
        }
        @keyframes countUp {
            0% {
                opacity: 0;
                transform: translateY(20px) scale(0.5);
            }
            60% {
                transform: translateY(-5px) scale(1.1);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        @keyframes pulse {
            0%, 100% {
                text-shadow: 0 0 10px ${colors.accent}66, 0 0 20px ${colors.accent}33;
            }
            50% {
                text-shadow: 0 0 20px ${colors.accent}99, 0 0 30px ${colors.accent}66, 0 0 40px ${colors.accent}33;
            }
        }
        .stat-label {
            font-size: 14px;
            color: #cbd5e1;
            margin-top: 4px;
            animation: fadeInUp 2s ease-out 0.3s forwards;
            opacity: 0;
        }
        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(10px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .cta-section {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            padding: 32px;
            border-radius: 12px;
            margin: 32px 0;
            text-align: center;
            border: 2px solid #fbbf24;
        }
        .cta-title {
            font-size: 22px;
            font-weight: 700;
            color: #92400e;
            margin-bottom: 12px;
        }
        .cta-text {
            font-size: 16px;
            color: #78350f;
            margin-bottom: 20px;
            line-height: 1.6;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff;
            padding: 16px 40px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 4px 12px ${colors.primary}66;
            transition: all 0.3s ease;
            animation: buttonPulse 2s ease-in-out infinite;
            position: relative;
            overflow: hidden;
        }
        .cta-button::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            animation: ripple 2s ease-out infinite;
        }
        @keyframes buttonPulse {
            0%, 100% {
                box-shadow: 0 4px 12px ${colors.primary}66;
            }
            50% {
                box-shadow: 0 4px 20px ${colors.primary}99, 0 0 30px ${colors.primary}66;
            }
        }
        @keyframes ripple {
            0% {
                width: 0;
                height: 0;
                opacity: 1;
            }
            100% {
                width: 300px;
                height: 300px;
                opacity: 0;
            }
        }
        .cta-button:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 6px 20px ${colors.primary}99;
        }
        .footer {
            background: #f8fafc;
            padding: 32px 30px;
            text-align: center;
            border-top: 1px solid #e2e8f0;
        }
        .signature {
            margin-bottom: 24px;
        }
        .signature-name {
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }
        .signature-title {
            font-size: 14px;
            color: #64748b;
            margin-bottom: 2px;
        }
        .contact-info {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-top: 16px;
        }
        .contact-item {
            display: flex;
            align-items: center;
            color: #475569;
            font-size: 14px;
            text-decoration: none;
        }
        .contact-item:hover {
            color: ${colors.primary};
        }
        .contact-icon {
            margin-right: 6px;
        }
        .divider {
            height: 1px;
            background: linear-gradient(to right, transparent, #cbd5e1, transparent);
            margin: 24px 0;
        }
        .section-heading {
            font-size: 18px;
            color: #0f172a;
            margin-bottom: 20px;
            font-weight: 700;
        }
        .section-heading .accent {
            color: ${colors.primary};
        }
        .cta-contact-box {
            background: #ffffff;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 24px;
            margin: 20px 0;
            text-align: left;
        }
        .cta-contact-item {
            display: flex;
            align-items: center;
            margin: 12px 0;
            color: #475569;
            font-size: 15px;
        }
        .cta-contact-icon {
            margin-right: 12px;
            font-size: 18px;
        }
        .social-links {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 20px;
        }
        .social-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff;
            text-decoration: none;
            font-size: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px ${colors.primary}33;
        }
        .social-link:hover {
            transform: translateY(-3px) scale(1.1);
            box-shadow: 0 4px 12px ${colors.primary}66;
        }
        @media only screen and (max-width: 600px) {
            .email-container {
                border-radius: 0;
            }
            .header {
                padding: 30px 20px;
            }
            .company-name {
                font-size: 24px;
            }
            .content {
                padding: 30px 20px;
            }
            .features-grid {
                grid-template-columns: 1fr;
            }
            .stat {
                display: block;
                margin: 12px 0;
            }
            .cta-section {
                padding: 24px 20px;
            }
            .cta-contact-box {
                padding: 16px;
            }
            .cta-contact-item {
                font-size: 14px;
                margin: 10px 0;
            }
            .contact-info {
                flex-direction: column;
                gap: 12px;
            }
            .social-links {
                margin-top: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-content">
                <div class="company-name">${data.companyName}</div>
                <div class="header-subtitle">Exclusive Website Prototype Offer</div>
            </div>
        </div>

        <div class="content">
            <div class="greeting">Hi ${data.firstName},</div>

            <p class="intro-text">
                I spent 10 minutes on <strong>${data.companyName}'s</strong> website today and saw real potential — but also <strong>3 conversion gaps</strong> that are likely costing you leads.
            </p>

            <p class="intro-text">
                The good news? <strong>They're fixable.</strong>
            </p>

            <div class="highlight-box">
                <h2>Here's what I'm offering:</h2>
                <p class="highlight-text">
                    I'll create a <strong>custom homepage prototype</strong> for ${data.companyName} — completely free. Not a template. A real design based on your brand, audience, and how your best customers think.
                </p>
            </div>

            <div style="margin: 32px 0;">
                <h3 class="section-heading">
                    What you'll get <span class="accent">(within 24 hours)</span>:
                </h3>
                <div class="deliverables">
                    <div class="deliverable-item">
                        <div class="checkmark"></div>
                        <div class="deliverable-text">Modern UI designed for trust + conversions</div>
                    </div>
                    <div class="deliverable-item">
                        <div class="checkmark"></div>
                        <div class="deliverable-text">Mobile-first layout that actually works</div>
                    </div>
                    <div class="deliverable-item">
                        <div class="checkmark"></div>
                        <div class="deliverable-text">Clear CTAs that guide visitors to inquire</div>
                    </div>
                    <div class="deliverable-item">
                        <div class="checkmark"></div>
                        <div class="deliverable-text">3-point audit showing what's holding you back right now</div>
                    </div>
                </div>
            </div>

            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🎨</div>
                    <div class="feature-title">Brand-Aligned Design</div>
                    <div class="feature-desc">Perfectly matches your identity</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <div class="feature-title">Mobile Optimized</div>
                    <div class="feature-desc">Looks great on all devices</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <div class="feature-title">Fast Delivery</div>
                    <div class="feature-desc">Ready in 24 hours</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <div class="feature-title">Conversion Focused</div>
                    <div class="feature-desc">Built to generate leads</div>
                </div>
            </div>

            <div class="stats-banner">
                <div class="stat">
                    <span class="stat-number">350+</span>
                    <span class="stat-label">Brands Helped</span>
                </div>
                <div class="stat">
                    <span class="stat-number">2018</span>
                    <span class="stat-label">Since</span>
                </div>
            </div>

            <p class="intro-text">
                <strong>No commitment. No sales pitch. Just value first.</strong>
            </p>

            <p class="intro-text">
                Use it as inspiration, share it with your team, or let us build it — your call.
            </p>

            <p class="intro-text">
                I've done this for <strong>350+ brands since 2018</strong>. Happy to do the same for ${data.companyName}.
            </p>

            <div class="cta-section">
                <div class="cta-title">Want me to send it over?</div>
                <div class="cta-text">
                    Just reply <strong>"Yes"</strong> or let me know a good time to share.
                </div>
                <a href="mailto:${data.email}?subject=Yes - Send the Prototype for ${data.companyName}" class="cta-button">
                    Yes, Send the Prototype
                </a>

                <div class="cta-contact-box">
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📞</span>
                        <a href="tel:${data.phone}" style="color: #475569; text-decoration: none;">${data.phone}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">✉️</span>
                        <a href="mailto:${data.email}" style="color: #475569; text-decoration: none;">${data.email}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📍</span>
                        <span>${data.address}</span>
                    </div>
                </div>
            </div>

            <div class="divider"></div>

            <p class="intro-text" style="text-align: center; color: #64748b; font-size: 14px;">
                Looking forward to helping ${data.companyName} reach its full potential.
            </p>
        </div>

        <div class="footer">
            <div class="signature">
                <div class="signature-name">${data.founderName}</div>
                <div class="signature-title">Founder, ${data.companyBrand}</div>
            </div>
            <div class="contact-info">
                <a href="tel:${data.phone}" class="contact-item">
                    <span class="contact-icon">📞</span>
                    ${data.phone}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="mailto:${data.email}" class="contact-item">
                    <span class="contact-icon">✉️</span>
                    ${data.email}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="https://${data.website}" class="contact-item">
                    <span class="contact-icon">🌐</span>
                    ${data.website}
                </a>
            </div>

            <div class="social-links">
                <a href="https://instagram.com/${data.instagram.replace('@', '')}" class="social-link" title="Follow us on Instagram" target="_blank">
                    📷
                </a>
                <a href="https://facebook.com/${data.facebook}" class="social-link" title="Like us on Facebook" target="_blank">
                    👍
                </a>
            </div>
        </div>
    </div>
</body>
</html>
  `.trim();
}

export function generateFollowUpEmail(data: EmailData): string {
  const colors = themeColors[data.theme];

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quick Follow-up - ${data.companyName}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f1f5f9;
            padding: 40px 20px;
            line-height: 1.6;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        .header {
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            padding: 30px;
            text-align: center;
        }
        .header-text {
            color: #ffffff;
            font-size: 18px;
            font-weight: 600;
            animation: fadeIn 0.8s ease-out;
        }
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-10px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .content {
            padding: 40px 30px;
        }
        .greeting {
            font-size: 18px;
            color: #0f172a;
            margin-bottom: 20px;
        }
        .paragraph {
            font-size: 16px;
            color: #334155;
            margin-bottom: 20px;
            line-height: 1.7;
        }
        .highlight-box {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border-left: 4px solid ${colors.accent};
            padding: 20px;
            margin: 28px 0;
            border-radius: 8px;
            animation: slideIn 0.6s ease-out 0.2s backwards;
        }
        @keyframes slideIn {
            0% {
                opacity: 0;
                transform: translateX(-20px);
            }
            100% {
                opacity: 1;
                transform: translateX(0);
            }
        }
        .highlight-title {
            font-size: 16px;
            font-weight: 700;
            color: #78350f;
            margin-bottom: 12px;
        }
        .highlight-item {
            font-size: 15px;
            color: #78350f;
            margin: 8px 0;
            padding-left: 20px;
            position: relative;
        }
        .highlight-item::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: ${colors.primary};
            font-weight: bold;
        }
        .value-prop {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin: 24px 0;
        }
        .value-card {
            background: #f8fafc;
            padding: 16px;
            border-radius: 8px;
            text-align: center;
            border: 2px solid #e2e8f0;
            animation: popUp 0.5s ease-out backwards;
        }
        .value-card:nth-child(1) {
            animation-delay: 0.3s;
        }
        .value-card:nth-child(2) {
            animation-delay: 0.4s;
        }
        @keyframes popUp {
            0% {
                opacity: 0;
                transform: scale(0.8);
            }
            100% {
                opacity: 1;
                transform: scale(1);
            }
        }
        .value-time {
            font-size: 28px;
            font-weight: 700;
            color: ${colors.primary};
            margin-bottom: 4px;
            animation: pulse 2s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% {
                text-shadow: 0 0 10px ${colors.primary}66;
            }
            50% {
                text-shadow: 0 0 20px ${colors.primary}99, 0 0 30px ${colors.primary}66;
            }
        }
        .value-label {
            font-size: 13px;
            color: #64748b;
            font-weight: 500;
        }
        .cta-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 32px;
            border-radius: 12px;
            margin: 32px 0;
            text-align: center;
            border: 2px solid #e2e8f0;
        }
        .cta-question {
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 20px;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff;
            padding: 16px 40px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 4px 12px ${colors.primary}66;
            transition: all 0.3s ease;
            animation: buttonPulse 2s ease-in-out infinite;
            position: relative;
            overflow: hidden;
        }
        .cta-button::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            animation: ripple 2s ease-out infinite;
        }
        @keyframes buttonPulse {
            0%, 100% {
                box-shadow: 0 4px 12px ${colors.primary}66;
            }
            50% {
                box-shadow: 0 4px 20px ${colors.primary}99, 0 0 30px ${colors.primary}66;
            }
        }
        @keyframes ripple {
            0% {
                width: 0;
                height: 0;
                opacity: 1;
            }
            100% {
                width: 300px;
                height: 300px;
                opacity: 0;
            }
        }
        .cta-button:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 6px 20px ${colors.primary}99;
        }
        .cta-contact-box {
            background: #ffffff;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            margin-top: 20px;
            text-align: left;
        }
        .cta-contact-item {
            display: flex;
            align-items: center;
            margin: 10px 0;
            color: #475569;
            font-size: 14px;
        }
        .cta-contact-icon {
            margin-right: 10px;
            font-size: 16px;
        }
        .footer {
            background: #f8fafc;
            padding: 30px;
            text-align: center;
            border-top: 1px solid #e2e8f0;
        }
        .signature {
            margin-bottom: 20px;
        }
        .signature-name {
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }
        .signature-title {
            font-size: 14px;
            color: #64748b;
        }
        .contact-info {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-top: 16px;
        }
        .contact-item {
            display: flex;
            align-items: center;
            color: #475569;
            font-size: 14px;
            text-decoration: none;
        }
        .contact-item:hover {
            color: ${colors.primary};
        }
        .contact-icon {
            margin-right: 6px;
        }
        .social-links {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 16px;
        }
        .social-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff;
            text-decoration: none;
            font-size: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px ${colors.primary}33;
        }
        .social-link:hover {
            transform: translateY(-3px) scale(1.1);
            box-shadow: 0 4px 12px ${colors.primary}66;
        }
        @media only screen and (max-width: 600px) {
            body {
                padding: 20px 10px;
            }
            .content {
                padding: 30px 20px;
            }
            .value-prop {
                grid-template-columns: 1fr;
            }
            .cta-section {
                padding: 24px 20px;
            }
            .cta-contact-box {
                padding: 16px;
            }
            .contact-info {
                flex-direction: column;
                gap: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-text">Quick Follow-up</div>
        </div>

        <div class="content">
            <div class="greeting">Hi ${data.firstName},</div>

            <p class="paragraph">
                I sent over an offer to create a free custom homepage prototype for <strong>${data.companyName}</strong> a few days ago.
            </p>

            <p class="paragraph">
                Not sure if it got buried in your inbox (happens to the best of us), so I wanted to ping you once more.
            </p>

            <div class="highlight-box">
                <div class="highlight-title">The offer still stands:</div>
                <div class="highlight-item">A personalized homepage design + conversion audit</div>
                <div class="highlight-item">Completely on us</div>
                <div class="highlight-item">No strings attached</div>
            </div>

            <div class="value-prop">
                <div class="value-card">
                    <div class="value-time">~3 hours</div>
                    <div class="value-label">For me to build</div>
                </div>
                <div class="value-card">
                    <div class="value-time">5 minutes</div>
                    <div class="value-label">For you to review</div>
                </div>
            </div>

            <div class="cta-section">
                <div class="cta-question">Want me to go ahead with it?</div>
                <a href="mailto:${data.email}?subject=Yes - Let's do it for ${data.companyName}" class="cta-button">
                    Yes, Let's Do It
                </a>

                <div class="cta-contact-box">
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📞</span>
                        <a href="tel:${data.phone}" style="color: #475569; text-decoration: none;">${data.phone}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">✉️</span>
                        <a href="mailto:${data.email}" style="color: #475569; text-decoration: none;">${data.email}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📍</span>
                        <span>${data.address}</span>
                    </div>
                </div>
            </div>

            <p class="paragraph" style="text-align: center; color: #64748b; font-size: 14px; margin-top: 32px;">
                Best regards,<br>
                <strong style="color: #0f172a;">${data.founderName}</strong>
            </p>
        </div>

        <div class="footer">
            <div class="signature">
                <div class="signature-name">${data.founderName}</div>
                <div class="signature-title">Founder, ${data.companyBrand}</div>
            </div>
            <div class="contact-info">
                <a href="tel:${data.phone}" class="contact-item">
                    <span class="contact-icon">📞</span>
                    ${data.phone}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="mailto:${data.email}" class="contact-item">
                    <span class="contact-icon">✉️</span>
                    ${data.email}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="https://${data.website}" class="contact-item">
                    <span class="contact-icon">🌐</span>
                    ${data.website}
                </a>
            </div>

            <div class="social-links">
                <a href="https://instagram.com/${data.instagram.replace('@', '')}" class="social-link" title="Follow us on Instagram" target="_blank">
                    📷
                </a>
                <a href="https://facebook.com/${data.facebook}" class="social-link" title="Like us on Facebook" target="_blank">
                    👍
                </a>
            </div>
        </div>
    </div>
</body>
</html>
  `.trim();
}


export function generateFollowUp2Email(data: EmailData): string {
  const colors = themeColors[data.theme];

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.companyName} Example - See What I Mean</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f1f5f9; padding: 40px 20px; line-height: 1.6;
        }
        .email-container {
            max-width: 600px; margin: 0 auto; background: #ffffff;
            border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        .header {
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            padding: 30px; text-align: center;
        }
        .header-text { color: #ffffff; font-size: 20px; font-weight: 700; margin-bottom: 4px; }
        .header-subtext { color: rgba(255, 255, 255, 0.9); font-size: 14px; }
        .content { padding: 40px 30px; }
        .greeting { font-size: 18px; color: #0f172a; margin-bottom: 20px; }
        .paragraph { font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.7; }
        .example-section { margin: 32px 0; }
        .example-title {
            font-size: 17px; font-weight: 700; color: #0f172a;
            margin-bottom: 20px; text-align: center;
        }
        .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 24px 0; }
        .comparison-card {
            background: #f8fafc; border-radius: 12px; padding: 20px;
            border: 2px solid #e2e8f0; position: relative; overflow: hidden;
        }
        .comparison-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0;
            height: 4px; background: ${colors.primary};
        }
        .comparison-card.before::before { background: #ef4444; }
        .comparison-card.after::before { background: #10b981; }
        .comparison-label {
            font-size: 12px; font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.5px; margin-bottom: 12px; display: inline-block;
            padding: 4px 12px; border-radius: 6px;
        }
        .comparison-card.before .comparison-label { background: #fee2e2; color: #991b1b; }
        .comparison-card.after .comparison-label { background: #d1fae5; color: #065f46; }
        .comparison-item {
            font-size: 14px; color: #475569; margin: 8px 0;
            padding-left: 20px; position: relative; line-height: 1.5;
        }
        .comparison-card.before .comparison-item::before {
            content: '✗'; position: absolute; left: 0; color: #ef4444; font-weight: bold;
        }
        .comparison-card.after .comparison-item::before {
            content: '✓'; position: absolute; left: 0; color: #10b981; font-weight: bold;
        }
        .metric-box {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 2px solid #e2e8f0; border-radius: 12px;
            padding: 16px; margin-top: 12px; text-align: center;
        }
        .metric-value { font-size: 24px; font-weight: 700; margin-bottom: 2px; }
        .comparison-card.before .metric-value { color: #ef4444; }
        .comparison-card.after .metric-value { color: #10b981; }
        .metric-label { font-size: 12px; color: #64748b; font-weight: 500; }
        .result-banner {
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
            border: 2px solid #10b981; border-radius: 12px;
            padding: 20px; margin: 24px 0; text-align: center;
        }
        .result-text {
            font-size: 18px; font-weight: 700; color: #065f46; margin-bottom: 8px;
        }
        .result-multiplier {
            font-size: 32px; font-weight: 900; color: #10b981;
            text-shadow: 0 2px 4px rgba(16, 185, 129, 0.2);
        }
        .cta-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 32px; border-radius: 12px; margin: 32px 0;
            text-align: center; border: 2px solid #e2e8f0;
        }
        .cta-question { font-size: 20px; font-weight: 700; color: #0f172a; margin-bottom: 20px; }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; padding: 16px 40px; border-radius: 8px;
            text-decoration: none; font-weight: 600; font-size: 16px;
            box-shadow: 0 4px 12px ${colors.primary}66; transition: all 0.3s ease;
        }
        .cta-button:hover {
            transform: translateY(-2px) scale(1.05); box-shadow: 0 6px 20px ${colors.primary}99;
        }
        .cta-contact-box {
            background: #ffffff; border: 2px solid #e2e8f0; border-radius: 12px;
            padding: 20px; margin-top: 20px; text-align: left;
        }
        .cta-contact-item {
            display: flex; align-items: center; margin: 10px 0;
            color: #475569; font-size: 14px;
        }
        .cta-contact-icon { margin-right: 10px; font-size: 16px; }
        .footer { background: #f8fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0; }
        .signature { margin-bottom: 20px; }
        .signature-name { font-size: 18px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
        .signature-title { font-size: 14px; color: #64748b; }
        .contact-info {
            display: flex; justify-content: center; align-items: center;
            flex-wrap: wrap; gap: 16px; margin-top: 16px;
        }
        .contact-item {
            display: flex; align-items: center; color: #475569;
            font-size: 14px; text-decoration: none;
        }
        .contact-item:hover { color: ${colors.primary}; }
        .contact-icon { margin-right: 6px; }
        .social-links { display: flex; justify-content: center; gap: 16px; margin-top: 16px; }
        .social-link {
            display: inline-flex; align-items: center; justify-content: center;
            width: 40px; height: 40px; border-radius: 50%;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; text-decoration: none; font-size: 20px;
            transition: all 0.3s ease; box-shadow: 0 2px 8px ${colors.primary}33;
        }
        .social-link:hover {
            transform: translateY(-3px) scale(1.1); box-shadow: 0 4px 12px ${colors.primary}66;
        }
        @media only screen and (max-width: 600px) {
            body { padding: 20px 10px; }
            .content { padding: 30px 20px; }
            .comparison-grid { grid-template-columns: 1fr; }
            .cta-section { padding: 24px 20px; }
            .cta-contact-box { padding: 16px; }
            .contact-info { flex-direction: column; gap: 12px; }
            .result-multiplier { font-size: 24px; }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-text">${data.companyName} Example</div>
            <div class="header-subtext">See what I mean</div>
        </div>
        <div class="content">
            <div class="greeting">Hi ${data.firstName},</div>
            <p class="paragraph">I know you're busy, so I'll keep this short.</p>
            <p class="paragraph">
                Instead of just talking about what we could do for <strong>${data.companyName}</strong>, I thought I'd show you what I mean.
            </p>
            <div class="example-section">
                <div class="example-title">Quick Before/After from a Recent Project</div>
                <div class="comparison-grid">
                    <div class="comparison-card before">
                        <div class="comparison-label">Before</div>
                        <div class="comparison-item">Confusing navigation</div>
                        <div class="comparison-item">Generic messaging</div>
                        <div class="comparison-item">Hidden CTAs</div>
                        <div class="metric-box">
                            <div class="metric-value">2.3%</div>
                            <div class="metric-label">Inquiry Rate</div>
                        </div>
                    </div>
                    <div class="comparison-card after">
                        <div class="comparison-label">After</div>
                        <div class="comparison-item">Clear value proposition</div>
                        <div class="comparison-item">Streamlined CTAs</div>
                        <div class="comparison-item">Trust signals visible</div>
                        <div class="metric-box">
                            <div class="metric-value">7.8%</div>
                            <div class="metric-label">Inquiry Rate</div>
                        </div>
                    </div>
                </div>
                <div class="result-banner">
                    <div class="result-text">Result</div>
                    <div class="result-multiplier">3.4x increase</div>
                </div>
            </div>
            <p class="paragraph">
                This is the kind of thinking I'd apply to <strong>${data.companyName}</strong>'s site — completely free to start.
            </p>
            <div class="cta-section">
                <div class="cta-question">Still interested? Just say the word.</div>
                <a href="mailto:${data.email}?subject=Yes - I'm interested for ${data.companyName}" class="cta-button">
                    Yes, I'm Interested
                </a>
                <div class="cta-contact-box">
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📞</span>
                        <a href="tel:${data.phone}" style="color: #475569; text-decoration: none;">${data.phone}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">✉️</span>
                        <a href="mailto:${data.email}" style="color: #475569; text-decoration: none;">${data.email}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📍</span>
                        <span>${data.address}</span>
                    </div>
                </div>
            </div>
            <p class="paragraph" style="text-align: center; color: #64748b; font-size: 14px; margin-top: 32px;">
                Cheers,<br>
                <strong style="color: #0f172a;">${data.founderName}</strong><br>
                <span style="color: #64748b; font-size: 13px;">${data.companyBrand}</span>
            </p>
        </div>
        <div class="footer">
            <div class="signature">
                <div class="signature-name">${data.founderName}</div>
                <div class="signature-title">Founder, ${data.companyBrand}</div>
            </div>
            <div class="contact-info">
                <a href="tel:${data.phone}" class="contact-item">
                    <span class="contact-icon">📞</span>
                    ${data.phone}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="mailto:${data.email}" class="contact-item">
                    <span class="contact-icon">✉️</span>
                    ${data.email}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="https://${data.website}" class="contact-item">
                    <span class="contact-icon">🌐</span>
                    ${data.website}
                </a>
            </div>
            <div class="social-links">
                <a href="https://instagram.com/${data.instagram.replace('@', '')}" class="social-link" title="Follow us on Instagram" target="_blank">📷</a>
                <a href="https://facebook.com/${data.facebook}" class="social-link" title="Like us on Facebook" target="_blank">👍</a>
            </div>
        </div>
    </div>
</body>
</html>
  `.trim();
}

export function generateFollowUp3Email(data: EmailData): string {
  const colors = themeColors[data.theme];

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Honest Question - ${data.firstName}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f1f5f9; padding: 40px 20px; line-height: 1.6;
        }
        .email-container {
            max-width: 600px; margin: 0 auto; background: #ffffff;
            border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        .header {
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            padding: 30px; text-align: center;
        }
        .header-text { color: #ffffff; font-size: 20px; font-weight: 700; }
        .content { padding: 40px 30px; }
        .greeting { font-size: 18px; color: #0f172a; margin-bottom: 20px; }
        .paragraph { font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.7; }
        .question-box {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border-left: 4px solid ${colors.accent};
            padding: 24px; margin: 28px 0; border-radius: 12px; text-align: center;
        }
        .question-text {
            font-size: 18px; font-weight: 700; color: #78350f; margin-bottom: 12px;
        }
        .subtitle-text {
            font-size: 14px; color: #92400e; margin-bottom: 20px;
        }
        .options-list {
            background: #ffffff; border-radius: 12px; padding: 24px; margin: 24px 0;
        }
        .option-item {
            display: flex; align-items: flex-start; padding: 16px;
            margin: 12px 0; border-radius: 10px; border: 2px solid #e2e8f0;
            transition: all 0.3s ease; cursor: pointer;
        }
        .option-item:hover {
            border-color: ${colors.primary}; background: #f8fafc;
            transform: translateX(4px);
        }
        .option-emoji {
            font-size: 28px; margin-right: 16px; min-width: 40px; text-align: center;
        }
        .option-content { flex: 1; }
        .option-title {
            font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 4px;
        }
        .option-description { font-size: 14px; color: #64748b; }
        .cta-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 32px; border-radius: 12px; margin: 32px 0;
            text-align: center; border: 2px solid #e2e8f0;
        }
        .cta-text {
            font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.6;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; padding: 16px 40px; border-radius: 8px;
            text-decoration: none; font-weight: 600; font-size: 16px;
            box-shadow: 0 4px 12px ${colors.primary}66; transition: all 0.3s ease;
            margin: 8px;
        }
        .cta-button:hover {
            transform: translateY(-2px) scale(1.05); box-shadow: 0 6px 20px ${colors.primary}99;
        }
        .cta-button.not-interested {
            background: linear-gradient(135deg, #64748b 0%, #475569 100%);
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.4);
        }
        .cta-button.not-interested:hover {
            box-shadow: 0 6px 20px rgba(100, 116, 139, 0.6);
        }
        .cta-button.timing {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
        }
        .cta-button.timing:hover {
            box-shadow: 0 6px 20px rgba(245, 158, 11, 0.6);
        }
        .cta-contact-box {
            background: #ffffff; border: 2px solid #e2e8f0; border-radius: 12px;
            padding: 20px; margin-top: 20px; text-align: left;
        }
        .cta-contact-item {
            display: flex; align-items: center; margin: 10px 0;
            color: #475569; font-size: 14px;
        }
        .cta-contact-icon { margin-right: 10px; font-size: 16px; }
        .footer { background: #f8fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0; }
        .signature { margin-bottom: 20px; }
        .signature-name { font-size: 18px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
        .signature-title { font-size: 14px; color: #64748b; }
        .contact-info {
            display: flex; justify-content: center; align-items: center;
            flex-wrap: wrap; gap: 16px; margin-top: 16px;
        }
        .contact-item {
            display: flex; align-items: center; color: #475569;
            font-size: 14px; text-decoration: none;
        }
        .contact-item:hover { color: ${colors.primary}; }
        .contact-icon { margin-right: 6px; }
        .social-links { display: flex; justify-content: center; gap: 16px; margin-top: 16px; }
        .social-link {
            display: inline-flex; align-items: center; justify-content: center;
            width: 40px; height: 40px; border-radius: 50%;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; text-decoration: none; font-size: 20px;
            transition: all 0.3s ease; box-shadow: 0 2px 8px ${colors.primary}33;
        }
        .social-link:hover {
            transform: translateY(-3px) scale(1.1); box-shadow: 0 4px 12px ${colors.primary}66;
        }
        @media only screen and (max-width: 600px) {
            body { padding: 20px 10px; }
            .content { padding: 30px 20px; }
            .question-box { padding: 20px; }
            .option-item { padding: 12px; }
            .option-emoji { font-size: 24px; min-width: 32px; }
            .cta-section { padding: 24px 20px; }
            .cta-button { display: block; margin: 8px 0; }
            .cta-contact-box { padding: 16px; }
            .contact-info { flex-direction: column; gap: 12px; }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-text">Honest Question</div>
        </div>
        <div class="content">
            <div class="greeting">Hi ${data.firstName},</div>
            <div class="question-box">
                <div class="question-text">Was my offer not interesting, or just bad timing?</div>
                <div class="subtitle-text">I'm refining our outreach, so genuinely curious</div>
            </div>
            <p class="paragraph">
                Just reply with one of the options below and I'll know what to do:
            </p>
            <div class="options-list">
                <div class="option-item">
                    <div class="option-emoji">❌</div>
                    <div class="option-content">
                        <div class="option-title">Not interested</div>
                        <div class="option-description">All good, I'll stop following up</div>
                    </div>
                </div>
                <div class="option-item">
                    <div class="option-emoji">⏰</div>
                    <div class="option-content">
                        <div class="option-title">Bad timing</div>
                        <div class="option-description">Want me to check back in a month?</div>
                    </div>
                </div>
                <div class="option-item">
                    <div class="option-emoji">✅</div>
                    <div class="option-content">
                        <div class="option-title">Still interested</div>
                        <div class="option-description">Let's make it happen</div>
                    </div>
                </div>
            </div>
            <div class="cta-section">
                <div class="cta-text">No hard feelings either way. Just click one of these:</div>
                <a href="mailto:${data.email}?subject=Re: Not interested&body=❌ Not interested" class="cta-button not-interested">
                    ❌ Not Interested
                </a>
                <a href="mailto:${data.email}?subject=Re: Bad timing - check back later&body=⏰ Bad timing - check back in a month" class="cta-button timing">
                    ⏰ Bad Timing
                </a>
                <a href="mailto:${data.email}?subject=Re: Still interested for ${data.companyName}&body=✅ Still interested - let's make it happen" class="cta-button">
                    ✅ Still Interested
                </a>
                <div class="cta-contact-box">
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📞</span>
                        <a href="tel:${data.phone}" style="color: #475569; text-decoration: none;">${data.phone}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">✉️</span>
                        <a href="mailto:${data.email}" style="color: #475569; text-decoration: none;">${data.email}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📍</span>
                        <span>${data.address}</span>
                    </div>
                </div>
            </div>
            <p class="paragraph" style="text-align: center; color: #64748b; font-size: 14px; margin-top: 32px;">
                Thanks,<br>
                <strong style="color: #0f172a;">${data.founderName}</strong>
            </p>
        </div>
        <div class="footer">
            <div class="signature">
                <div class="signature-name">${data.founderName}</div>
                <div class="signature-title">Founder, ${data.companyBrand}</div>
            </div>
            <div class="contact-info">
                <a href="tel:${data.phone}" class="contact-item">
                    <span class="contact-icon">📞</span>
                    ${data.phone}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="mailto:${data.email}" class="contact-item">
                    <span class="contact-icon">✉️</span>
                    ${data.email}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="https://${data.website}" class="contact-item">
                    <span class="contact-icon">🌐</span>
                    ${data.website}
                </a>
            </div>
            <div class="social-links">
                <a href="https://instagram.com/${data.instagram.replace('@', '')}" class="social-link" title="Follow us on Instagram" target="_blank">📷</a>
                <a href="https://facebook.com/${data.facebook}" class="social-link" title="Like us on Facebook" target="_blank">👍</a>
            </div>
        </div>
    </div>
</body>
</html>
  `.trim();
}

export function generateFollowUp4Email(data: EmailData): string {
  const colors = themeColors[data.theme];

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Last Note - ${data.firstName}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f1f5f9; padding: 40px 20px; line-height: 1.6;
        }
        .email-container {
            max-width: 600px; margin: 0 auto; background: #ffffff;
            border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        .header {
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            padding: 30px; text-align: center;
        }
        .header-text { color: #ffffff; font-size: 20px; font-weight: 700; margin-bottom: 4px; }
        .header-subtext { color: rgba(255, 255, 255, 0.9); font-size: 14px; }
        .content { padding: 40px 30px; }
        .greeting { font-size: 18px; color: #0f172a; margin-bottom: 20px; }
        .paragraph { font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.7; }
        .farewell-box {
            background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);
            border-left: 4px solid ${colors.primary};
            padding: 20px; margin: 28px 0; border-radius: 12px;
        }
        .farewell-text {
            font-size: 16px; color: #0c4a6e; line-height: 1.6; text-align: center;
        }
        .tips-section { margin: 32px 0; }
        .tips-title {
            font-size: 18px; font-weight: 700; color: #0f172a;
            margin-bottom: 20px; text-align: center;
        }
        .tips-subtitle {
            font-size: 14px; color: #64748b; text-align: center;
            margin-bottom: 24px; font-style: italic;
        }
        .tip-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 2px solid #e2e8f0; border-radius: 12px;
            padding: 20px; margin: 16px 0; position: relative;
            transition: all 0.3s ease;
        }
        .tip-card:hover {
            border-color: ${colors.primary}; transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        .tip-number {
            position: absolute; top: -12px; left: 20px;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; width: 32px; height: 32px;
            border-radius: 50%; display: flex; align-items: center;
            justify-content: center; font-weight: 700; font-size: 14px;
            box-shadow: 0 2px 8px ${colors.primary}66;
        }
        .tip-title {
            font-size: 16px; font-weight: 700; color: #0f172a;
            margin-bottom: 8px; padding-top: 8px;
        }
        .tip-description { font-size: 14px; color: #475569; line-height: 1.6; }
        .tip-example {
            background: #f1f5f9; border-left: 3px solid ${colors.accent};
            padding: 12px 16px; margin-top: 12px; border-radius: 6px;
            font-size: 13px; color: #334155; font-style: italic;
        }
        .tip-impact {
            display: inline-block; background: #d1fae5; color: #065f46;
            padding: 4px 12px; border-radius: 6px; font-size: 12px;
            font-weight: 600; margin-top: 8px;
        }
        .cta-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 32px; border-radius: 12px; margin: 32px 0;
            text-align: center; border: 2px solid #e2e8f0;
        }
        .cta-text {
            font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.6;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; padding: 16px 40px; border-radius: 8px;
            text-decoration: none; font-weight: 600; font-size: 16px;
            box-shadow: 0 4px 12px ${colors.primary}66; transition: all 0.3s ease;
        }
        .cta-button:hover {
            transform: translateY(-2px) scale(1.05); box-shadow: 0 6px 20px ${colors.primary}99;
        }
        .ps-section {
            background: #fef3c7; border: 2px dashed #f59e0b;
            border-radius: 12px; padding: 20px; margin: 24px 0; text-align: center;
        }
        .ps-label {
            font-size: 14px; font-weight: 700; color: #92400e;
            margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .ps-text { font-size: 15px; color: #78350f; line-height: 1.6; }
        .footer { background: #f8fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0; }
        .signature { margin-bottom: 20px; }
        .signature-name { font-size: 18px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
        .signature-title { font-size: 14px; color: #64748b; margin-bottom: 2px; }
        .signature-company { font-size: 14px; color: #64748b; font-weight: 600; }
        .contact-info {
            display: flex; justify-content: center; align-items: center;
            flex-wrap: wrap; gap: 16px; margin-top: 16px;
        }
        .contact-item {
            display: flex; align-items: center; color: #475569;
            font-size: 14px; text-decoration: none;
        }
        .contact-item:hover { color: ${colors.primary}; }
        .contact-icon { margin-right: 6px; }
        .social-links { display: flex; justify-content: center; gap: 16px; margin-top: 16px; }
        .social-link {
            display: inline-flex; align-items: center; justify-content: center;
            width: 40px; height: 40px; border-radius: 50%;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; text-decoration: none; font-size: 20px;
            transition: all 0.3s ease; box-shadow: 0 2px 8px ${colors.primary}33;
        }
        .social-link:hover {
            transform: translateY(-3px) scale(1.1); box-shadow: 0 4px 12px ${colors.primary}66;
        }
        @media only screen and (max-width: 600px) {
            body { padding: 20px 10px; }
            .content { padding: 30px 20px; }
            .farewell-box { padding: 16px; }
            .tip-card { padding: 16px; }
            .tip-number { width: 28px; height: 28px; font-size: 12px; }
            .cta-section { padding: 24px 20px; }
            .ps-section { padding: 16px; }
            .contact-info { flex-direction: column; gap: 12px; }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-text">Last Note From Me</div>
            <div class="header-subtext">Promise!</div>
        </div>
        <div class="content">
            <div class="greeting">Hi ${data.firstName},</div>
            <p class="paragraph">This will be my last email — promise!</p>
            <div class="farewell-box">
                <div class="farewell-text">
                    I know your inbox is probably flooded, and maybe a free homepage redesign just isn't a priority for <strong>${data.companyName}</strong> right now. Totally fair.
                </div>
            </div>
            <p class="paragraph">
                But before I close your file, I wanted to leave you with <strong>3 quick wins</strong> you can implement yourself (no us required):
            </p>
            <div class="tips-section">
                <div class="tips-title">Free Quick Wins for ${data.companyName}</div>
                <div class="tips-subtitle">Implement these today, see results tomorrow</div>
                
                <div class="tip-card">
                    <div class="tip-number">1</div>
                    <div class="tip-title">Hero Section</div>
                    <div class="tip-description">
                        Replace generic taglines with a specific outcome. Instead of "We help businesses grow," try something measurable and time-bound.
                    </div>
                    <div class="tip-example">
                        Example: "Get 30% more qualified leads in 90 days"
                    </div>
                </div>

                <div class="tip-card">
                    <div class="tip-number">2</div>
                    <div class="tip-title">Social Proof</div>
                    <div class="tip-description">
                        Add client logos or testimonials above the fold. Trust signals are conversion gold.
                    </div>
                    <div class="tip-impact">📈 +15-20% conversion increase</div>
                </div>

                <div class="tip-card">
                    <div class="tip-number">3</div>
                    <div class="tip-title">Mobile CTA</div>
                    <div class="tip-description">
                        Make sure your "Contact Us" button is thumb-reachable on mobile. Test it on your phone right now.
                    </div>
                    <div class="tip-example">
                        Why it matters: 60% of traffic is mobile-first
                    </div>
                </div>
            </div>
            <p class="paragraph">
                Feel free to use these ideas. If you ever need help executing, you know where to find me.
            </p>
            <div class="cta-section">
                <div class="cta-text">
                    <strong>Wishing ${data.companyName} all the best!</strong>
                </div>
            </div>
            <div class="ps-section">
                <div class="ps-label">P.S.</div>
                <div class="ps-text">
                    If things change and you want that free prototype later, my door's always open. Just reply to this thread.
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="signature">
                <div class="signature-name">${data.founderName}</div>
                <div class="signature-title">Founder</div>
                <div class="signature-company">${data.companyBrand}</div>
            </div>
            <div class="contact-info">
                <a href="tel:${data.phone}" class="contact-item">
                    <span class="contact-icon">📞</span>
                    ${data.phone}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="mailto:${data.email}" class="contact-item">
                    <span class="contact-icon">✉️</span>
                    ${data.email}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="https://${data.website}" class="contact-item">
                    <span class="contact-icon">🌐</span>
                    ${data.website}
                </a>
            </div>
            <div class="social-links">
                <a href="https://instagram.com/${data.instagram.replace('@', '')}" class="social-link" title="Follow us on Instagram" target="_blank">📷</a>
                <a href="https://facebook.com/${data.facebook}" class="social-link" title="Like us on Facebook" target="_blank">👍</a>
            </div>
        </div>
    </div>
</body>
</html>
  `.trim();
}

export function generateReEngagementEmail(data: EmailData): string {
  const colors = themeColors[data.theme];

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Case Study for ${data.companyName}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f1f5f9; padding: 40px 20px; line-height: 1.6;
        }
        .email-container {
            max-width: 600px; margin: 0 auto; background: #ffffff;
            border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        .header {
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            padding: 30px; text-align: center;
        }
        .header-text { color: #ffffff; font-size: 20px; font-weight: 700; margin-bottom: 4px; }
        .header-subtext { color: rgba(255, 255, 255, 0.9); font-size: 14px; }
        .content { padding: 40px 30px; }
        .greeting { font-size: 18px; color: #0f172a; margin-bottom: 20px; }
        .paragraph { font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.7; }
        .context-box {
            background: #f8fafc; border-left: 4px solid ${colors.primary};
            padding: 16px 20px; margin: 24px 0; border-radius: 8px;
        }
        .context-text { font-size: 15px; color: #475569; line-height: 1.6; }
        .case-study-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 2px solid #e2e8f0; border-radius: 12px;
            padding: 32px; margin: 28px 0;
        }
        .case-study-label {
            display: inline-block; background: ${colors.primary};
            color: #ffffff; padding: 6px 16px; border-radius: 6px;
            font-size: 12px; font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.5px; margin-bottom: 20px;
        }
        .case-study-title {
            font-size: 20px; font-weight: 700; color: #0f172a;
            margin-bottom: 24px; text-align: center;
        }
        .case-study-grid {
            display: grid; grid-template-columns: 1fr;
            gap: 16px; margin: 20px 0;
        }
        .case-detail {
            background: #ffffff; border: 2px solid #e2e8f0;
            border-radius: 10px; padding: 20px;
            transition: all 0.3s ease;
        }
        .case-detail:hover {
            border-color: ${colors.primary}; transform: translateX(4px);
        }
        .case-detail-label {
            font-size: 12px; font-weight: 700; color: ${colors.primary};
            text-transform: uppercase; letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        .case-detail-value {
            font-size: 16px; color: #0f172a; line-height: 1.5;
        }
        .result-banner {
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
            border: 3px solid #10b981; border-radius: 12px;
            padding: 24px; margin: 24px 0; text-align: center;
        }
        .result-label {
            font-size: 14px; font-weight: 700; color: #065f46;
            text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;
        }
        .result-text {
            font-size: 28px; font-weight: 900; color: #10b981;
            text-shadow: 0 2px 4px rgba(16, 185, 129, 0.2);
            margin-bottom: 4px;
        }
        .result-subtext {
            font-size: 14px; color: #065f46;
        }
        .cta-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 32px; border-radius: 12px; margin: 32px 0;
            text-align: center; border: 2px solid #e2e8f0;
        }
        .cta-text {
            font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.6;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; padding: 16px 40px; border-radius: 8px;
            text-decoration: none; font-weight: 600; font-size: 16px;
            box-shadow: 0 4px 12px ${colors.primary}66; transition: all 0.3s ease;
            margin: 8px;
        }
        .cta-button:hover {
            transform: translateY(-2px) scale(1.05); box-shadow: 0 6px 20px ${colors.primary}99;
        }
        .cta-button.secondary {
            background: linear-gradient(135deg, #64748b 0%, #475569 100%);
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.4);
        }
        .cta-button.secondary:hover {
            box-shadow: 0 6px 20px rgba(100, 116, 139, 0.6);
        }
        .cta-contact-box {
            background: #ffffff; border: 2px solid #e2e8f0; border-radius: 12px;
            padding: 20px; margin-top: 20px; text-align: left;
        }
        .cta-contact-item {
            display: flex; align-items: center; margin: 10px 0;
            color: #475569; font-size: 14px;
        }
        .cta-contact-icon { margin-right: 10px; font-size: 16px; }
        .footer { background: #f8fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0; }
        .signature { margin-bottom: 20px; }
        .signature-name { font-size: 18px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
        .signature-title { font-size: 14px; color: #64748b; }
        .contact-info {
            display: flex; justify-content: center; align-items: center;
            flex-wrap: wrap; gap: 16px; margin-top: 16px;
        }
        .contact-item {
            display: flex; align-items: center; color: #475569;
            font-size: 14px; text-decoration: none;
        }
        .contact-item:hover { color: ${colors.primary}; }
        .contact-icon { margin-right: 6px; }
        .social-links { display: flex; justify-content: center; gap: 16px; margin-top: 16px; }
        .social-link {
            display: inline-flex; align-items: center; justify-content: center;
            width: 40px; height: 40px; border-radius: 50%;
            background: linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%);
            color: #ffffff; text-decoration: none; font-size: 20px;
            transition: all 0.3s ease; box-shadow: 0 2px 8px ${colors.primary}33;
        }
        .social-link:hover {
            transform: translateY(-3px) scale(1.1); box-shadow: 0 4px 12px ${colors.primary}66;
        }
        @media only screen and (max-width: 600px) {
            body { padding: 20px 10px; }
            .content { padding: 30px 20px; }
            .case-study-section { padding: 24px 20px; }
            .case-detail { padding: 16px; }
            .result-text { font-size: 24px; }
            .cta-section { padding: 24px 20px; }
            .cta-button { display: block; margin: 8px 0; }
            .cta-contact-box { padding: 16px; }
            .contact-info { flex-direction: column; gap: 12px; }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-text">Fresh Case Study</div>
            <div class="header-subtext">You might find this interesting</div>
        </div>
        <div class="content">
            <div class="greeting">Hi ${data.firstName},</div>
            <p class="paragraph">
                I know we chatted (or tried to) a while back about <strong>${data.companyName}</strong>'s website.
            </p>
            <div class="context-box">
                <div class="context-text">
                    I just wrapped a project that might interest you based on what I learned about your business.
                </div>
            </div>
            <div class="case-study-section">
                <span class="case-study-label">Recent Project</span>
                <div class="case-study-title">Similar Challenge, Proven Results</div>
                
                <div class="case-study-grid">
                    <div class="case-detail">
                        <div class="case-detail-label">Industry</div>
                        <div class="case-detail-value">Similar to ${data.companyName}</div>
                    </div>
                    
                    <div class="case-detail">
                        <div class="case-detail-label">Challenge</div>
                        <div class="case-detail-value">Low conversion rates despite good traffic</div>
                    </div>
                    
                    <div class="case-detail">
                        <div class="case-detail-label">Solution</div>
                        <div class="case-detail-value">Simplified user journey + trust-focused design</div>
                    </div>
                </div>

                <div class="result-banner">
                    <div class="result-label">Result</div>
                    <div class="result-text">4x increase</div>
                    <div class="result-subtext">in demo requests within 6 weeks</div>
                </div>
            </div>
            <p class="paragraph">
                If you're facing similar challenges, let's talk. If not, no worries — just thought it might be relevant for <strong>${data.companyName}</strong>.
            </p>
            <div class="cta-section">
                <div class="cta-text">
                    <strong>Want to see the full breakdown?</strong>
                </div>
                <a href="mailto:${data.email}?subject=Yes - Send me the ${data.companyName} case study&body=Hi ${data.founderName},%0D%0A%0D%0AI'd like to see the full case study and discuss how this might apply to ${data.companyName}." class="cta-button">
                    📊 Send Me the Case Study
                </a>
                <a href="mailto:${data.email}?subject=Let's schedule a call about ${data.companyName}&body=Hi ${data.founderName},%0D%0A%0D%0AI'd like to schedule a call to discuss this approach for ${data.companyName}." class="cta-button secondary">
                    📞 Let's Schedule a Call
                </a>
                <div class="cta-contact-box">
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📞</span>
                        <a href="tel:${data.phone}" style="color: #475569; text-decoration: none;">${data.phone}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">✉️</span>
                        <a href="mailto:${data.email}" style="color: #475569; text-decoration: none;">${data.email}</a>
                    </div>
                    <div class="cta-contact-item">
                        <span class="cta-contact-icon">📍</span>
                        <span>${data.address}</span>
                    </div>
                </div>
            </div>
            <p class="paragraph" style="text-align: center; color: #64748b; font-size: 14px; margin-top: 32px;">
                Best,<br>
                <strong style="color: #0f172a;">${data.founderName}</strong>
            </p>
        </div>
        <div class="footer">
            <div class="signature">
                <div class="signature-name">${data.founderName}</div>
                <div class="signature-title">Founder, ${data.companyBrand}</div>
            </div>
            <div class="contact-info">
                <a href="tel:${data.phone}" class="contact-item">
                    <span class="contact-icon">📞</span>
                    ${data.phone}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="mailto:${data.email}" class="contact-item">
                    <span class="contact-icon">✉️</span>
                    ${data.email}
                </a>
                <span style="color: #cbd5e1;">|</span>
                <a href="https://${data.website}" class="contact-item">
                    <span class="contact-icon">🌐</span>
                    ${data.website}
                </a>
            </div>
            <div class="social-links">
                <a href="https://instagram.com/${data.instagram.replace('@', '')}" class="social-link" title="Follow us on Instagram" target="_blank">📷</a>
                <a href="https://facebook.com/${data.facebook}" class="social-link" title="Like us on Facebook" target="_blank">👍</a>
            </div>
        </div>
    </div>
</body>
</html>
  `.trim();
}
