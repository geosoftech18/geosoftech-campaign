import { useState, useEffect } from 'react';
import EmailEditor from './components/EmailEditor';
import EmailPreview from './components/EmailPreview';
import TemplateManager from './components/TemplateManager';
import { Mail, Eye, Code, Smartphone, Monitor } from 'lucide-react';

export interface FormData {
  firstName: string;
  companyName: string;
  phone: string;
  website: string;
  email: string;
  address: string;
  founderName: string;
  companyBrand: string;
  instagram: string;
  facebook: string;
  theme: 'blue' | 'green' | 'purple' | 'orange' | 'slate' | 'red';
}

function App() {
  const [formData, setFormData] = useState<FormData>({
    firstName: 'John',
    companyName: 'TechCorp',
    phone: '+1 (555) 123-4567',
    website: 'www.geosoftech.com',
    email: 'hello@geosoftech.com',
    address: '123 Business Ave, Suite 100, City, State 12345',
    founderName: 'Amar Korde',
    companyBrand: 'GEO Softech',
    instagram: '@geosoftech',
    facebook: 'geosoftech',
    theme: 'blue'
  });

  const [viewMode, setViewMode] = useState<'preview' | 'html'>('preview');
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [emailType, setEmailType] = useState<'initial' | 'followup' | 'followup2' | 'followup3' | 'followup4' | 'reengagement'>('initial');
  const [showTemplateManager, setShowTemplateManager] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-2 rounded-xl shadow-lg">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Email Campaign Builder Pro</h1>
                <p className="text-sm text-slate-600">Advanced conversion-focused email designer</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {/* Email Type Toggle */}
              <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-lg">
                <button
                  onClick={() => setEmailType('initial')}
                  className={`px-3 py-2 rounded-md transition-all text-sm font-medium ${
                    emailType === 'initial'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Initial
                </button>
                <button
                  onClick={() => setEmailType('followup')}
                  className={`px-3 py-2 rounded-md transition-all text-sm font-medium ${
                    emailType === 'followup'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  FU #1
                </button>
                <button
                  onClick={() => setEmailType('followup2')}
                  className={`px-3 py-2 rounded-md transition-all text-sm font-medium ${
                    emailType === 'followup2'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  FU #2
                </button>
                <button
                  onClick={() => setEmailType('followup3')}
                  className={`px-3 py-2 rounded-md transition-all text-sm font-medium ${
                    emailType === 'followup3'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  FU #3
                </button>
                <button
                  onClick={() => setEmailType('followup4')}
                  className={`px-3 py-2 rounded-md transition-all text-sm font-medium ${
                    emailType === 'followup4'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  FU #4
                </button>
                <button
                  onClick={() => setEmailType('reengagement')}
                  className={`px-3 py-2 rounded-md transition-all text-sm font-medium ${
                    emailType === 'reengagement'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Re-Engage
                </button>
              </div>

              {/* Device Toggle */}
              <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-lg">
                <button
                  onClick={() => setDeviceMode('desktop')}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-all ${
                    deviceMode === 'desktop'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Desktop View"
                >
                  <Monitor className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDeviceMode('mobile')}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-all ${
                    deviceMode === 'mobile'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Mobile View"
                >
                  <Smartphone className="w-4 h-4" />
                </button>
              </div>

              {/* View Mode Toggle */}
              <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-lg">
                <button
                  onClick={() => setViewMode('preview')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all ${
                    viewMode === 'preview'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Eye className="w-4 h-4" />
                  <span className="text-sm font-medium hidden sm:inline">Preview</span>
                </button>
                <button
                  onClick={() => setViewMode('html')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all ${
                    viewMode === 'html'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Code className="w-4 h-4" />
                  <span className="text-sm font-medium hidden sm:inline">HTML</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Editor Panel */}
          <EmailEditor
            formData={formData}
            setFormData={setFormData}
            onOpenTemplates={() => setShowTemplateManager(true)}
          />

          {/* Preview Panel */}
          <EmailPreview
            formData={formData}
            viewMode={viewMode}
            deviceMode={deviceMode}
            emailType={emailType}
          />
        </div>
      </main>

      {/* Template Manager Modal */}
      {showTemplateManager && (
        <TemplateManager
          onClose={() => setShowTemplateManager(false)}
          onLoadTemplate={(template) => {
            setFormData({
              firstName: template.recipient_first_name,
              companyName: template.recipient_company_name,
              phone: template.sender_phone,
              website: template.sender_website,
              email: template.sender_email,
              address: template.sender_address,
              founderName: template.sender_name,
              companyBrand: template.sender_company,
              instagram: template.sender_instagram,
              facebook: template.sender_facebook,
              theme: template.theme
            });
            setShowTemplateManager(false);
          }}
          currentFormData={formData}
        />
      )}
    </div>
  );
}

export default App;
